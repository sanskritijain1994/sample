<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>M-D Array</title>
</head>

<body>
    <?php

    $details = array(
        "Item" => array(
            "Milk" => array(
                "Q1" => 340,
                "Q2" => 680,
                "Q3" => 535
            ),
            "Egg" => array(
                "Q1" => 604,
                "Q2" => 583,
                "Q3" => 490
            ),
            "Bread" => array(
                "Q1" => 38,
                "Q2" => 10,
                "Q3" => 50
            )
        ),
        "Item1" => array(
            "Milk" => array(
                "Q1" => 335,
                "Q2" => 684,
                "Q3" => 389
            ),
            "Egg" => array(
                "Q1" => 365,
                "Q2" => 490,
                "Q3" => 385
            ),
            "Bread" => array(
                "Q1" => 35,
                "Q2" => 48,
                "Q3" => 15
            )
        ),
        "Item2" => array(
            "Milk" => array(
                "Q1" => 336,
                "Q2" => 595,
                "Q3" => 366
            ),
            "Egg" => array(
                "Q1" => 484,
                "Q2" => 594,
                "Q3" => 385
            ),
            "Bread" => array(
                "Q1" => 80,
                "Q2" => 39,
                "Q3" => 20
            )
        )
    );
    $details1 = array(
        array(
            "location" => "kolkata",
            "quater" => "Q1",
            "Milk" => 340,
            "Egg" => 604,
            "Bread" => 38
        ),
        array(
            "location" => "Delhi",
            "quater" => "Q1",
            "Milk" => 335,
            "Egg" => 365,
            "Bread" => 35
        ),
        array(
            "location" => "Mumbai",
            "quater" => "Q1",
            "Milk" => 336,
            "Egg" => 484,
            "Bread" => 80
        ),
        array(
            "location" => "kolkata",
            "quater" => "Q2",
            "Milk" => 680,
            "Egg" => 583,
            "Bread" => 10
        ),
        array(
            "location" => "Delhi",
            "quater" => "Q2",
            "Milk" => 684,
            "Egg" => 490,
            "Bread" => 48
        ),
        array(
            "location" => "Mumbai",
            "quater" => "Q2",
            "Milk" => 595,
            "Egg" => 594,
            "Bread" => 39
        ),
        array(
            "location" => "kolkata",
            "quater" => "Q3",
            "Milk" => 535,
            "Egg" => 490,
            "Bread" => 50
        ),
        array(
            "location" => "Delhi",
            "quater" => "Q3",
            "Milk" => 389,
            "Egg" => 385,
            "Bread" => 15
        ),
        array(
            "location" => "Mumbai",
            "quater" => "Q3",
            "Milk" => 366,
            "Egg" => 385,
            "Bread" => 20
        )
    );
    
    foreach ($details1 as $key => $value) {
        # code...
        print_r($value);
    }

    echo '<h2><u>' . 'Multi Dimensional Array' . '</u></h2><br>';
    echo "<br><table border='1px' cellpadding='5px' cellspacing='0px'>";
    echo '<tr><th></th><th colspan="4">Location = "Kolkata"</th>' . '<th colspan="4">Location = "Delhi"</th>' . '<th colspan="4">Location = "Mumbai"</th></tr>';
    echo '<tr><th></th><th colspan="4">Item</th>' . '<th colspan="4">Item</th>' . '<th colspan="4">Item</th></tr>';
    echo '<tr><th rowspan="3">Time</th>';
    foreach ($details as $key1 => $value1) {
        # code...
        //print_r($key1);
        //echo '<tr>';
        foreach ($value1 as $key2 => $value2) {
            # code...
            //print_r($key2 );
            //print_r($value2);
            //echo '<tr>';
            echo '<th>' . $key2;
            foreach ($value2 as $key3 => $value3) {
                # code...
                //print_r($key3);
                //print_r($value3);
                echo '<td>' . $value3 . '</td>';
            }
        }
        echo '</tr>';
    }

    echo '</tr>';
    echo '</table>';
    ?>
</body>

</html>