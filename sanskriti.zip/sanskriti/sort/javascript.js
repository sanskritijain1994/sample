var mobile = [
  { company: "Samsung", model: "Galaxy", memory: 64, price: 15000 },
  { company: "Nokia", model: "S730", memory: 128, price: 22000 },
  { company: "Xiaomi", model: "Note", memory: 32, price: 12000 },
  { company: "Motoroala", model: "G10", memory: 32, price: 15000 },
  { company: "Apple", model: "S12", memory: 64, price: 25000 },
];

function generateTable(table, data) {
  //addProduct();
  //sorted();
  for (let element of data) {
    let row = table.insertRow();
    for (key in element) {
      let cell = row.insertCell();
      let text = document.createTextNode(element[key]);
      cell.appendChild(text);
    }
  }
}
let table = document.querySelector("table");
let data = Object.keys(mobile[0]);
generateTable(table, mobile);
console.log(mobile);

function sorted() {
  let c;

  //let order = document.getElementById("order").value;
  // var select = document.getElementById("sel");

  // selectElement = document.querySelector('#sel');
  // var option = selectElement.value;
  // c=mobile.find(obj => obj.company)
  // console.log(c);
  // if(c = mobile.find(obj => obj.company==attr)){
  //     return true;
  //     console.log(c);
  // }

  // console.log("select "+ option);
  // let dropdownList = document.getElementById('sel');
  //   dropdownList.onchange = (ev) =>{
  //     let selecetedIndex = dropdownList.selectedIndex.value;
  //     console.log("Selected index is: " + selecetedIndex);}
  let dropdownList = document.getElementById("sel");
  dropdownList.onchange = (ev) => {
    let attr = dropdownList.value;
    console.log("Selected value is: " + attr);
    mobile.forEach(element => {
      if (element.company == attr) {
        mobile.sort((a, b) =>
          a.company > b.company ? 1 : b.company > a.company ? -1 : 0
        );
        console.log(mobile);
        //generateTable(table, data);
      }  
    });
    // if (mobile.company == attr) {
    //   mobile.sort((a, b) =>
    //     a.company > b.company ? 1 : b.company > a.company ? -1 : 0
    //   );
    //   console.log(mobile);
    //   //generateTable(table, data);
    // }
    // else if(c = mobile.find(obj => obj.model==attr)){
    //   mobile.sort((a,b) => (a.model > b.model) ? 1 : ((b.model > a.model) ? -1 : 0));

    // }
    // else if(c = mobile.find(obj => obj.memory==attr)){
    //   mobile.sort((a,b) => a.memory - b.memory);
    // }
    // else if(c = mobile.find(obj => obj.price==attr))
    // {
    //   mobile.sort((a,b) => a.price - b.price);
    //}
  };
  // // for (const element of mobile) {
  // //   if(attr==element.company){
  // //     mobile.sort((a,b) => (a.company > b.company) ? 1 : ((b.company > a.company) ? -1 : 0)); }
  // // }
  // // mobile.forEach(element => {
  // //   if(attr==element.company){
  // //     mobile.sort((a,b) => (a.company > b.company) ? 1 : ((b.company > a.company) ? -1 : 0));
  // //     //
  // //   }
  // // });
  //generateTable(table, data);
  //Acending Order
  // mobile.sort((a,b) => (a.company > b.company) ? 1 : ((b.company > a.company) ? -1 : 0));
  // mobile.sort((a,b) => (a.model > b.model) ? 1 : ((b.model > a.model) ? -1 : 0));
  // mobile.sort((a,b) => a.memory - b.memory);
  // mobile.sort((a,b) => a.price - b.price);
  //Decending Order
  //mobile.sort((a,b) => (a.company > b.company) ? -1 : ((b.company > a.company) ? 1 : 0));
  //mobile.sort((a,b) => (a.model > b.model) ? -1 : ((b.model > a.model) ? 1 : 0));
  //  mobile.sort((a,b) => a.memory - b.memory);
  //  mobile.reverse();
  //mobile.sort((a,b) => a.price - b.price);
  //mobile.reverse();
}
