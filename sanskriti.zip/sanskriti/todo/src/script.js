window.onload = () => {
    const div1 = document.querySelector(".container");}
    const item = document.getElementById("new-task");
    const add = document.getElementById("add");

    


// function add() {
//     let task=[];
//     let item = document.getElementById("new-task");
//     task.push(item);
//     console.log(task);
// }