var arr = [];
var str1;
str1 = "<table id='header'>"
str1 += "<tr>" + "<th>" + "SKU" + "</th>" + "<th>" + "Name" + "</th>" + "<th>" + "Price" + "</th>" + "<th>" + "Quantity" + "</th>" + "<th>" + "Action" + "</th>";
str1 += "</tr>";
str1 += "</table>"
var arr=[];
$('#header').hide();
$('.error').hide();
$('.success').hide();
var letters = /^[A-Za-z]+$/;
var str;

str = "<table id='product_list'>";

$(document).ready(function () {
    $('#add_product').click(function () {
        var sku = $("#product_sku").val();
        var nam = $("#product_name").val();
        var price = $("#product_price").val();
        var qun = $("#product_quantity").val();

      var c= check(sku,nam,price,qun);
      if(c == true){
        $('#header').show();
            $("#header").html(str1);
            
            var obj={'sku' : sku,'name' : nam,'price':price,'quantity':qun,'edit':'edit','delete':'delete'};
            arr.push(obj);
            print();
      }
       
    });
});

function print(){
    str="";
    for (var i in arr) {
        
            str+= "<tr>"+"<td>"+arr[i].sku+"</td>"+"<td>"+arr[i].name+"</td>"+"<td>"+arr[i].price+
           "</td>"+"<td>"+arr[i].quantity+"</td>"+"<td  + i onclick=edit(this.id) id='edt"+ "'>"+"<a href=#  >"+ arr[i].edit + "</a>"+
           "</td>"+"<td onclick=dele(this.id) id='del" + i + "'>"+"<a href=#>"+arr[i].delete+"</a>"+"</td>"+"</tr>";
    }
    $('#product_list').html(str);
    console.log(arr)
}



function edit(e){
    var lastChar=e.charAt(e.length - 1);
    for (var i in arr) {
        if(i==lastChar)
        {
           var one= arr[i]['sku'];
           var two = arr[i]['name'];
           var three = arr[i]['price'];
           var four = arr[i]['quantity'];
           $('#product_sku').val(one);
           $('#product_name').val(two);
           $('#product_price').val(three);
           $('#product_quantity').val(four);
           $('#add_product').hide();
           $('#upd_product').show();
           upd(lastChar);
        }
    }
    
}
function upd(idd){
    $('#upd_product').click(function(){
        console.log(idd);
        
       var on = $('#product_sku').val();
         var tw=  $('#product_name').val();
          var thr= $('#product_price').val();
          var fou = $('#product_quantity').val();

        var gg=  check(on,tw,thr,fou);
        if(gg == true){
           for (var i in arr) {
                if(i==idd)
                {
                arr[i]['sku'] = on;
                arr[i]['name'] = tw;
                arr[i]['price'] = thr;
                arr[i]['quantity'] =fou;
                }
            $('#add_product').show();
            $('#upd_product').hide();
            }
        print();
        }
    })
    
}




function dele(d){
    alert("Confirm you want to delete");
   var lastChar=d.charAt(d.length - 1);
   delete arr[lastChar];
   print();
}


function check(sku,nam,price,qun){
    if(sku ==""){
        $("#product_sku").css('border-color', 'red');
        $('.error').show();
    }else if(!$.isNumeric( sku )){
        $('.error').show();
    }else{
        var a=1;
        $('.error').hide();
        $("#product_sku").css('border-color', 'black');
    }

    ////////////////////////////////////////////////////////
    if(nam ==""){
        $("#product_name").css('border-color', 'red');
        $('.error').show();
    }else if(nam.match(letters)){
        $('.error').hide();
        $("#product_name").css('border-color', 'black');

        var b=1;
    }else{
         $('.error').show();
         $("#product_name").css('border-color', 'red');
    }
    //////////////////////////////////////////////////////
    if(price ==""){ 
        $("#product_price").css('border-color', 'red');
        $('.error').show();
    }else if(!$.isNumeric( price )){
        $('.error').show();
    }else{
        var c=1;
        $('.error').hide();
        $("#product_price").css('border-color', 'black');
    }
    ///////////////////////////////////////////////
    if(qun ==""){ 
        $("#product_quantity").css('border-color', 'red');
        $('.error').show();
    }else if(!$.isNumeric( qun )){
        $('.error').show();
    }else{
        var d=1;
        $('.error').hide();
        $("#product_quantity").css('border-color', 'black');
    }

    if(a==1 && b==1 && c==1 && d==1){
        $('.success').show();
        
        return true;
}
}
