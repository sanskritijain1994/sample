let product = [];
$(document).ready(function () {
  $("#add_product").on("click", function () {
    validation();
    // $(".edit").on("click", function () {
    //   //console.log('hi');
    //   //console.log(id);
    //   var id = $(".edit").attr("id"); //get id
    //   console.log(id);
    //   edit(id);
    // });
    $(".delete").on("click", function () {
      var id = $(".remrow").attr("id");
      $(this).parent().parent().remove();
      removeitem(id);
    });
  });
});

function addProduct() {
  var products = {
    id: $("#product_sku").val(),
    name: $("#product_name").val(),
    price: $("#product_price").val(),
    quantity: $("#product_quantity").val(),
  };
  product.push(products);
}
function display() {
  addProduct();
  var myTable = "<table>";
  product.forEach((value) => {
    myTable +=
      "<tr><td>" +
      value.id +
      "</td><td>" +
      value.name +
      "</td><td>" +
      value.price +
      "</td><td>" +
      value.quantity +
      "</td><td onclick=edit(this.id) id='edt" +
      value +
      "'><a href=#  >" +
      "Edit" +
      "</a>" +
      "<a  href='#'  class='delete'>" +
      "Delete" +
      "</a>" +
      "</td></tr>";
  });
  myTable += "</table>";
  console.log(myTable);
  $("tbody").html(myTable);
}
function validation() {
  var id = $("#product_sku").val();
  var name = $("#product_name").val();
  var price = $("#product_price").val();
  var quantity = $("#product_quantity").val();
  var letters = /^[A-Za-z]+$/;
  $(".error").hide();
  $(".success").hide();
  if (id == "" && name == "" && price == "" && quantity == "") {
    $("#product_sku,#product_name,#product_price,#product_quantity").css(
      "border-color",
      "red"
    );
    $(".error").show();
  } else if (id == "" || !$.isNumeric(id)) {
    $("#product_sku").css("border-color", "red");
    $(".error").show();
    return;
  } else if (name == "" || !name.match(letters)) {
    $("#product_name").css("border-color", "red");
    $(".error").show();
    return;
  } else if (price == "" || !$.isNumeric(price)) {
    $("#product_price").css("border-color", "red");
    $(".error").show();
    return;
  } else if (quantity == "" || !$.isNumeric(quantity)) {
    $("#product_quantity").css("border-color", "red");
    $(".error").show();
    return;
  } else {
    $(".success").show();
    return display();
  }
}

function edit(e) {
  //console.log(e);
  var last = e.charAt(e.length - 1);
  //console.log(last);
  for (var i in product) {
    if (i == last) {
      var one = product[i]["id"];
      var two = product[i]["name"];
      var three = product[i]["price"];
      var four = product[i]["quantity"];
      $("#product_sku").val(one);
      $("#product_name").val(two);
      $("#product_price").val(three);
      $("#product_quantity").val(four);
      $("#add_product").hide();
      $("#upd_product").show();
      update(last);
    }
  }
}

function update(idd) {
  $("#upd_product").click(function () {
    console.log(idd);

    var on = $("#product_sku").val();
    var tw = $("#product_name").val();
    var thr = $("#product_price").val();
    var fou = $("#product_quantity").val();

    var gg = validation();
    if (gg == true) {
      for (var i in product) {
        if (i == idd) {
          product[i]["id"] = on;
          product[i]["name"] = tw;
          product[i]["price"] = thr;
          product[i]["quantity"] = fou;
        }
        $("#add_product").show();
        $("#upd_product").hide();
      }
      display();
    }
  });
}

function removeitem(row) {
  alert("Confirm you want to delete");
  const itemToRemoveIndex = product.findIndex(function (item) {
    return item.row === row;
  });
  if (itemToRemoveIndex !== -1) {
    product.splice(itemToRemoveIndex, 1);
  }
}

// var id;
// function edit(id) {
//   // $(".wrapper input").val("");
//   // console.log(id);
//   // id = $(this).data("id"); //get id
//   // //filter json array and get value only where match
//   // var pro = $(product).filter(function (i, n) {
//   //   return n.row === id;
//   // });
//   for (var i in product) {
//     if (i == id) {
//       var one = product[i]["id"];
//       var two = product[i]["name"];
//       var three = product[i]["price"];
//       var four = product[i]["quantity"];
//       $("#product_sku").val(one);
//       $("#product_name").val(two);
//       $("#product_price").val(three);
//       $("#product_quantity").val(four);
//       $("#add_product").hide();
//       $("#upd_product").show();
//       update(id);
//     }
//   }
//   // for (var i in product) {
//   //   $("#product_sku").val(pro[i].id);
//   //   $("#product_name").val(pro[i].name);
//   //   $("#product_price").val(pro[i].price);
//   //   $("#product_quantity").val(pro[i].quantity);

//   // console.log("hi");
//   // $("#add_product").hide();
//   // $("#upd_product").show();
//   // update();
//   //}
// }

// function update(id) {
//   $("#upd_product").click(function () {
//     console.log("hi");
//     console.log(id);
//     if (this.row == id) {
//       this.id = $("#product_sku").val();
//       this.name = $("#product_name").val();
//       this.price = $("#product_price").val();
//       this.quantity = $("#product_quantity").val();
//       return true;
//     }
//     // for (var i in product) {
//     //   if (i == idd) {
//     //     product[i]["id"] = $("#prodyct_sku").val();
//     //     product[i]["name"] = $("#product_name").val();
//     //     product[i]["price"] = $("#product_price").val();
//     //     product[i]["quantity"] = $("#product_quantity").val();
//     //   }
//     //   $("#add_product").show();
//     //   $("#upd_product").hide();
//     // }
//     for (var i in product) {
//       product[i]["id"] = $("#prodyct_sku").val();
//       product[i]["name"] = $("#product_name").val();
//       product[i]["price"] = $("#product_price").val();
//       product[i]["quantity"] = $("#product_quantity").val();
//     }
//     $("#add_product").show();
//     $("#upd_product").hide();
//     display();
//   });
//   // display();
// }
