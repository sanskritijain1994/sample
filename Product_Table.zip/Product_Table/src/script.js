let product = [];
$(document).ready(function () {
  $("#add_product").on("click", function () {
    display();
  });
});

function addProduct() {
  var products = {
    id: $("#product_sku").val(),
    name: $("#product_name").val(),
    price: $("#product_price").val(),
    quantity: $("#product_quantity").val(),
  };
  product.push(products);
}

function display() {
  validation();
  addProduct();
  validation();
  var myTable = "<table>";

  product.forEach((value, i) => {
    myTable +=
      "<tr><td>" +
      value.id +
      "</td><td>" +
      value.name +
      "</td><td>" +
      value.price +
      "</td><td>" +
      value.quantity +
      "<td><a  href='#' class='edit'>" +
      "Edit" +
      "</a>" +
      "<a  href='#'  class='delete'>" +
      "Delete" +
      "</a>" +
      "</td></tr>";
  });
  myTable += "</table>";
  console.log(myTable);
  $("#add").html(myTable);
}
function validation() {
  var id = $("#product_sku").val();
  var name = $("#product_name").val();
  var letters = /^[A-Za-z]+$/;
  $(".error").hide();
  $(".success").hide();
  if (id == "" || !$.isNumeric(id)) {
    $("#product_sku").css("border-color", "red");
    $(".error").show();
  } else if (name == "" || !name.match(letters)) {
    $("#product_name").css("border-color", "red");
    $(".error").show();
  } else {
    // $(".error").hide();
    $(".success").show();
  }
  return;
}
