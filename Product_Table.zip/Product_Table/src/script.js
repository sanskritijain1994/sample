let product = [];
$(document).ready(function () {
  $("#add_product").on("click", function () {
    display();
  });
});

function addProduct() {
  var products = {
    id: $("#product_sku").val(),
    name: $("#product_name").val(),
    price: $("#product_price").val(),
    quantity: $("#product_quantity"),
  };
  product.push(products);
}

function display() {
  addProduct();
  var myTable = "<table>";

  product.forEach((value, i) => {
    myTable +=
      "<tr><td>" +
      value.id +
      "</td><td>" +
      value.name +
      "</td><td>" +
      value.price +
      "</td><td>" +
      value.quantity +
      "</td></tr>";
  });
  myTable += "</table>";
  console.log(myTable);
  $("#add").text(myTable);
}
