var products = [
  { id: "100", name: "iPhone 4S", brand: "Apple", os: "iOS" },
  { id: "101", name: "Moto X", brand: "Motorola", os: "Android" },
  { id: "102", name: "iPhone 6", brand: "Apple", os: "iOS" },
  { id: "103", name: "Samsung Galaxy S", brand: "Samsung", os: "Android" },
  { id: "104", name: "Google Nexus", brand: "ASUS", os: "Android" },
  { id: "105", name: "Surface", brand: "Microsoft", os: "Windows" },
];
$("div").append(
  "<select id='sel' onchange='filterText()'><option>-Select-</option><option>Apple</option><option>Motorola</option><option>Samsung</option><option>ASUS</option><option>Microsoft</option></select> <select id='sel1' onchange='filterText1()'><option>-Select-</option><option>iOS</option><option>Android</option><option>Windows</option></selection>"
);
$("thead").append(
  '<tr><th>ID</th><th>Name</th><th id="brand">Brand</th><th id="os">Operating System</th><th>Remove</th>'
);
products.forEach(function (item) {
  $("tbody").append(
    "<tr class='content'><td>" +
      item.id +
      "</td><td>" +
      item.name +
      "</td><td>" +
      item.brand +
      "</td><td>" +
      item.os +
      "</td><td>" +
      "<button>X</button>" +
      "</td></tr>"
  );
});
$("#search").append('<input type="text" placeholder="Search" id="text"> ');

function filterText() {
  var rex = new RegExp($("#sel").val());

  $(".content").hide();
  $(".content")
    .filter(function () {
      return rex.test($(this).text());
    })
    .show();
}
function filterText1() {
  var rex1 = new RegExp($("#sel1").val());

  $(".content").hide();
  $(".content")
    .filter(function () {
      return rex1.test($(this).text());
    })
    .show();
}

$("#text").keyup(function () {
  var value = this.value;

  $("table tbody")
    .find("tr")
    .each(function (index) {
      if (index === 0) return;
      var id = $(this).find("td").first().text();
      $(this).toggle(id.indexOf(value) !== -1);
    });
  $("table tbody tr").each(function () {
    var found = false;
    $(this).each(function () {
      if ($(this).text().toLowerCase().indexOf(value.toLowerCase()) >= 0) {
        found = "true";
      }
    });
    if (found == "true") {
      $(this).show();
    } else {
      $(this).hide();
    }
  });
});

$(".content button").click(function () {
  $(this).closest("tr").hide();
});
