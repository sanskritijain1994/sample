$(document).ready(function () {
  var max_fields = 5;
  var wrapper = $(".cate");
  var list1 = $(".li1");
  var list2 = $(".li2");

  var x = 1;

  $(wrapper).on("click", ".btn1", function (e) {
    console.log("1");
    e.preventDefault();
    if (x < max_fields) {
      x++;
      console.log(x);
      $(this)
        .parent("li")
        .append(
          '<li><a href="#">Clothes</a><button class="btn1">+</button>' +
            '<ul><li><a href="#">T-shirt</a><button>+</button></li><li><a href="#">Trousers</a><button>+</button></li></ul></li><br>'
        );
    }
  });

  $(list1).on("click", ".bt1", function (e) {
    console.log("1");
    e.preventDefault();
    if (x < max_fields) {
      x++;
      console.log(x);
      $(this)
        .parent("li")
        .append(
          '<li><a href="#">T-Shirts</a><button class="bt1">+</button></li>'
        );
    }
  });

  // var wrap = $(".cate1");
  // $(wrap).on("click", ".btn2", function (e) {
  //   console.log("1");
  //   e.preventDefault();
  //   if (x < max_fields) {
  //     x++;
  //     console.log(x);
  //     $(this)
  //       .parent("li")
  //       .append(
  //         '<li><a href="#">Electronics</a><button class="btn1">+</button>' +
  //           '<ul><li><a href="#">Mobile</a><button>+</button></li><li><a href="#">Tabs  </a><button>+</button></li></ul></li><br>'
  //       );
  //   }
  // });
});
