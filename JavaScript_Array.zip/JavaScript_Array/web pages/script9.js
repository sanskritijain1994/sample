 function deleteRow()
 {
  document.querySelectorAll('#table .myCheck:checked').forEach(e => {
    e.parentNode.parentNode.remove();
      });
 }