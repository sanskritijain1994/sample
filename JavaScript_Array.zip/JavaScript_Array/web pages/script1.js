var mobile = [
    { company: "Samsung", model: "Galaxy", memory: 64, price: 15000 },
    { company: "Nokia", model: "S730", memory: 128, price: 22000 },
    { company: "Xiaomi", model: "Note", memory: 32, price: 12000 },
    { company: "Motoroala", model: "G10", memory: 32, price: 15000 },
    { company: "Apple", model: "S12", memory: 64, price: 25000 },
  ];
  function display()
{
  var myTable = "<table>"
  myTable += '<tr><th>' + 
             'Company' + 
             '</th><th>' + 
             'Model' + 
             '</th><th>' + 
             'Memory' + 
             '</th><th>' +
             'Price'+
             '</th></tr>'
  
  mobile.forEach((value,i)=>{
    myTable += '<tr><td>'+ value.company +
    '</td><td>' + value.model +
    '</td><td>' + value.memory +
    '</td><td>' + value.price 
    '</td></tr>';
  });
  myTable += "</table>";
  console.log(myTable);
  document.getElementById('table').innerHTML = myTable;
}