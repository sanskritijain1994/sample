let arr = [ { company: 'Samsung', model: 'Galaxy', memory: 64, price: 15000,ratings:0, }, 
            { company: "Nokia", model: "S730", memory: 128, price: 22000, ratings:0,}, 
            { company: "Xiomi", model: "Note", memory: 32, price: 12000,ratings:0, }, 
            { company: "Motorola", model: "G10", memory: 32, price: 15000,ratings:0, }, 
            { company: 'Apple', model: "S20", memory: 64, price: 25000,ratings:0, }];

let arr1 = [];
function rate() { 
    var selectedproduct = document.getElementById("inp1").value; 
    var rati = document.getElementById("inp2").value;
    // var obj = { 'select': selectedproduct, 'rat': rating } 
    // // console.log(obj); 
    // var dat = "<th>Rating</th>"; 
    // arr.push(obj);
 // // console.log(arr); 
 // arr.forEach(element => { 
    // dat = "<tr><td>" + (element.rat) + "</td></tr>";
 // }
  // ); 
  // document.getElementById("demo1").innerHTML = dat; 
  // document.getElementById("demo2").innerHTML = dat; 
  // document.getElementById("demo3").innerHTML = dat; 
  // document.getElementById("demo4").innerHTML = dat; 
  // document.getElementById("demo5").innerHTML = dat; 
  for (const i in arr) { for (const j in arr[i]){ 
    if(arr[i][j]==selectedproduct){ 
        // console.log(arr[i][j]) ;
        arr[i]['ratings']=rati; 
        console.log(rati);
         document.getElementById('demo'+i).innerHTML = rati; 
        } } }}