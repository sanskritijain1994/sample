let arr = [
  {
    company: "Samsung",
    model: "Galaxy",
    memory: 64,
    price: 15000,
    quantity: 20,
  },
  { company: "Nokia", model: "S730", memory: 128, price: 22000, quantity: 15 },
  { company: "Xiomi", model: "Note", memory: 32, price: 12000, quantity: 21 },
  { company: "Motorola", model: "G10", memory: 32, price: 15000, quantity: 13 },
  { company: "Apple", model: "S20", memory: 64, price: 25000, quantity: 18 },
];
let arr1 = [];
function add() {
  var dropValue = document.getElementById("inp1").value;
  var inputValue = document.getElementById("inp").value;
  var obj = {
    drop: dropValue,
    inpval: inputValue
  };
  // console.log(obj);
  arr.push(obj);
  // console.log(arr);
  for (const i in arr) {
    for (const j in arr[i]) {
      if (arr[i][j] == dropValue) {
        var quantity1 = arr[i]["quantity"];
        var finalQun = quantity1 - inputValue;
        arr[i]["quantity"] = finalQun;
        var str = "<table id='one'>";
        str += "<tr>";
        for (const k in arr) {
          if (arr[k]["company"] == dropValue) {
            for (const l in arr[k]) {
              str += "<td>" + l + "<br>" + arr[k][l] + "</td>";
            }
          }
          str += "</tr>";
        }
        str += "</table>";
      }
    }
  }
  arr1.push(str);
  console.log(arr1);
  document.getElementById("demo").innerHTML = arr1;
}
