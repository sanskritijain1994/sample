var mobile = [
  { company: "Samsung", model: "Galaxy", memory: 64, price: 15000 },
  { company: "Nokia", model: "S730", memory: 128, price: 22000 },
  { company: "Xiaomi", model: "Note", memory: 32, price: 12000 },
  { company: "Motoroala", model: "G10", memory: 32, price: 15000 },
  { company: "Apple", model: "S12", memory: 64, price: 25000 },
];
    
function display(mobile) {
  
  var myTable = "<table>"
  myTable += '<tr><th>' + 
             'Company' + 
             '</th><th>' + 
             'Model' + 
             '</th><th>' + 
             'Memory' + 
             '</th><th>' +
             'Price'+
             '</th></tr>'
  
  mobile.forEach((value,i)=>{
    myTable += '<tr><td>'+ value.company +
    '</td><td>' + value.model +
    '</td><td>' + value.memory +
    '</td><td>' + value.price 
    '</td></tr>';
  });
  myTable += "</table>";
  console.log(myTable);
  document.getElementById('table').innerHTML = myTable;
}

const sortByDropdown = document.querySelector(".sort-by");
const sortOrderDropdown = document.querySelector(".sort-order");
const container = document.querySelector(".products");



const ascendingSort = (sortByValue) => {
  return mobile.sort((a, b) => {
    if (a[sortByValue] < b[sortByValue]) return -1;
    if (a[sortByValue] > b[sortByValue]) return 1;
    return 0;
  });
};

const descendingSort = (sortByValue) => {
  return mobile.sort((a, b) => {
    if (a[sortByValue] < b[sortByValue]) return 1;
    if (a[sortByValue] > b[sortByValue]) return -1;
    return 0;
  });
};

sortByDropdown.addEventListener("change", () => {
  const sortByValue = sortByDropdown.value; // price or ram value
  const sortOrderValue = sortOrderDropdown.value; // asc or desc value

  const sorted =
    sortOrderValue === "desc"
      ? descendingSort(sortByValue)
      : ascendingSort(sortByValue);

  display(sorted);
});

sortOrderDropdown.addEventListener("change", () => {
  const event = new Event("change");
  const sortByValue = sortByDropdown.value;

  if (sortByValue) {
    sortByDropdown.dispatchEvent(event);
  }
});

