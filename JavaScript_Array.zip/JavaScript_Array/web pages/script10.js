let arr = [{ company: "Samsung", model: "Galaxy", memory: 64, price: 15000, quantity: 20, },
            { company: "Nokia", model: "S730", memory: 128, price: 22000, quantity: 15 },
            { company: "Xiomi", model: "Note", memory: 32, price: 12000, quantity: 21 },
            { company: "Motorola", model: "G10", memory: 32, price: 15000, quantity: 13 },
            { company: "Apple", model: "S20", memory: 64, price: 25000, quantity: 18 },
        ];
        function generateTable(table, data) {
            for (let element of data) {
              let row = table.insertRow();
              for (key in element) {
                let cell = row.insertCell();
                let text = document.createTextNode(element[key]);
                cell.appendChild(text);
              }
            }
          }
          // console.log(mobile);
          let table = document.querySelector("table");
          let data = Object.keys(arr[0]);
          generateTable(table, arr);
let arr1 = [];
function update() {
  var dropValue = document.getElementById("inp1").value;
  var inputValue = document.getElementById("inp").value;
  var obj = { drop: dropValue, inpval: inputValue };
  // console.log(dropValue);
  // console.log(inputValue);
  // arr.push(obj);
  // console.log(arr);
  for (const i in arr) {
    // console.log(arr[i]);
    for (const j in arr[i]) {
      // console.log(arr[i][j]);
      if (arr[i][j] == dropValue) {
        // console.log(dropValue);
        var quantity1 = arr[i]["quantity"];
        // var quantity1 = inputValue; 
        arr[i]["quantity"] = inputValue;
        // console.log(arr[i]["quantity"]);
        var dat = "<table>";
        arr.forEach((element) => {
          dat +=
            "<tr><td>" +
            element.campany +
            "</td><td>" +
            element.model +
            "</td><td>" +
            element.memory +
            "</td><td>" +
            element.price +
            "</td><td>" +
            element.quantity +
            "</td></tr>";
        });
        dat += "</table>";
        document.getElementById("demo").innerHTML = dat;
      }
    }
  }
}
