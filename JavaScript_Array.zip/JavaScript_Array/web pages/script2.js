var mobile = [
  { company: "Samsung", model: "Galaxy", memory: 64, price: 15000 },
  { company: "Nokia", model: "S730", memory: 128, price: 22000 },
  { company: "Xiaomi", model: "Note", memory: 32, price: 12000 },
  { company: "Motoroala", model: "G10", memory: 32, price: 15000 },
  { company: "Apple", model: "S12", memory: 64, price: 25000 },
];

function search() {
  var text = "";
  var txt = document.getElementById("ref").value;
  var id = document.getElementById("sel").value;
  var new_ar = [];
  mobile.forEach((element) => {
    if (
      element.company == txt ||
      element.memory == txt ||
      element.model == txt ||
      element.price == txt
    ) {
      new_ar.push(element);
      console.log(new_ar);
    }
  });
  function generateTable(table, data) {
    for (let element of data) {
      let row = table.insertRow();
      for (key in element) {
        let cell = row.insertCell();
        let text = document.createTextNode(element[key]);
        cell.appendChild(text);
      }
    }
  }
  let table = document.querySelector("table");
  let data = Object.keys(mobile[0]);
  generateTable(table, new_ar);
}
