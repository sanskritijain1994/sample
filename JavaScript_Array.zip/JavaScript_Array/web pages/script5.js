var mobile = [
  { company: "Samsung", model: "Galaxy", memory: 64, price: 15000 },
  { company: "Nokia", model: "S730", memory: 128, price: 22000 },
  { company: "Xiaomi", model: "Note", memory: 32, price: 12000 },
  { company: "Motoroala", model: "G10", memory: 32, price: 15000 },
  { company: "Apple", model: "S12", memory: 64, price: 25000 },
];
function filter() {
  var text = "";
  var txt = document.getElementById("minp").value;
  var txt1 = document.getElementById("maxp").value;
  console.log(txt, txt1);
  var new_ar = [];
  mobile.forEach((element) => {
    if (element.price >= txt && element.price <= txt1) {
      console.log(element);
      new_ar.push(element);
      console.log(new_ar);
    }
  });

  var myTable = "<table>";
  myTable +=
    "<tr><th>" +
    "Company" +
    "</th><th>" +
    "Model" +
    "</th><th>" +
    "Memory" +
    "</th><th>" +
    "Price" +
    "</th></tr>";

  new_ar.forEach((value, i) => {
    myTable +=
      "<tr><td>" +
      value.company +
      "</td><td>" +
      value.model +
      "</td><td>" +
      value.memory +
      "</td><td>" +
      value.price;
    ("</td></tr>");
  });
  myTable += "</table>";
  console.log(myTable);
  document.getElementById("demo").innerHTML = myTable;
}
