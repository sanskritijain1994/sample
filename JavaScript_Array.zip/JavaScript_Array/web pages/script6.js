let arr = [
  {
    company: "Samsung",
    model: "Galaxy",
    memory: 64,
    price: 15000,
    quantity: 20,
  },
  { company: "Nokia", model: "S730", memory: 128, price: 22000, quantity: 15 },
  { company: "Xiomi", model: "Note", memory: 32, price: 12000, quantity: 21 },
  { company: "Motorola", model: "G10", memory: 32, price: 15000, quantity: 13 },
  { company: "Apple", model: "S20", memory: 64, price: 25000, quantity: 18 },
];

function generateTable(table, data) {
  for (let element of data) {
    let row = table.insertRow();
    for (key in element) {
      let cell = row.insertCell();
      let text = document.createTextNode(element[key]);
      cell.appendChild(text);
    }
  }
}
let table = document.querySelector("table");
let data = Object.keys(arr[0]);
generateTable(table, arr);

let arr1 = [];
var header = { Discrip: "Discription", Qun: "Quantity", pric: "Amount" };
arr1.push(header);
console.log(arr1);
var obj = document.querySelector("#addclick");
// console.log(obj);
obj.addEventListener("click", function () {
  var drop_value = document.getElementById("inp1").value;
  var qun_number = document.getElementById("inp").value;
  for (const i in arr) {
    for (const j in arr[i]) {
      if (arr[i][j] == drop_value) {
        var sum = arr[i].price * qun_number;
        var obj1 = { company: drop_value, quantity: qun_number, price: sum };
      }
    }
  }
  arr1.push(obj1);
  var str = "<table>";
  for (const i in arr1) {
    str += "<tr>";
    for (const j in arr1[i]) {
      str += "<td>" + arr1[i][j] + "</td>";
    }
    str += "</tr>";
  }
  str += "</table>";
  document.getElementById("demo").innerHTML = str;
  // console.log(arr1);
  // console.log(obj1);
  console.log(arr1);
});
var total = 0;
var genbill = document.querySelector("#total_amt");
genbill.addEventListener("click", function () {
  for (const i in arr1) {
    for (const j in arr1[i]) {
      if (j == "price") {
        var pri = arr1[i][j];
        total = total + pri;
      }
    }
  }
  console.log(total);
  document.querySelector("#tt").innerHTML = total;
  document.querySelector("#rr").style.display = "block";
});
