<?php
session_start();
?>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expense Maneger</title>
    <link rel="stylesheet" href="./style.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="./script.js"></script>

</head>

<body>
    <h1 style="text-align:center"><u>Expense Manager</u></h1>
    <br>

    <div>
        <form action="" method="post">
            <span class="err"> * Required Field</span><br><br>
            <select name="expence" required="required">
                <option> Grocery</option>
                <option> Veggies</option>
                <option> Travelling</option>
                <option> Miscellaneous</option>
            </select> <br> <br>
            <label>Name</label>
            <input type="text" name="name"><br><br>
            <label>Quantity</label>
            <input type="text" name="quantity"> <br> <br>
            <label>Rate</label>
            <input type="text" name="Rate"> <br> <br>
            <label>Income</label>
            <input type="text" name="income"> <br> <br>
            <input type="submit" name="add" value="ADD">

        </form>
    </div>
    <?php
    if (!isset($_SESSION['arr'])) {
        $_SESSION['arr'] = array();
    }

    $expence = $_POST['expence'];
    $name = $_POST['name'];
    $income = $_POST['income'];
    $quantity = $_POST['quantity'];
    $Rate = $_POST['Rate'];
    $total_expence = $quantity * $Rate;
    $balance = $income - $total_expence;

    $budge = array(
        "expence" => $expence,
        "name" => $name,
        "income" => $income,
        "total_expence" => $total_expence,
        "balance" => $balance,
    );

    array_push($_SESSION['arr'], $budge);
    echo "<table border='2px'>";
    echo "<tr>
        <th>Type</th>
        <th>Name</th>
        <th>Income</th>
        <th>Expence</th>
        <th>Balance</th>
        <th colspan='2'>Action</th>
           </tr>";
    foreach ($_SESSION['arr'] as $v1) {
        echo "<tr>";
        foreach ($v1 as $v2) {
            echo "<td> $v2 </td>";
        }
        echo "<td><button style='background-color:lightgreen' class='edit'>Edit</button></td>";
        echo "<td><button style='background-color:#ff4d4d' class='delete'>Delete</button></td>";
        echo "</tr>";
    }
    echo "</table>";

    ?>
</body>

</html>