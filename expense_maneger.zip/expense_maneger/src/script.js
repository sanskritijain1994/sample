$(document).ready(function () {
    $(".delete").on("click", function () {
        var id = $(".remrow").attr("id");
        $(this).parent().parent().remove();
        removeitem(id);
      });
})
function removeitem(row) {
    alert("Confirm you want to delete");
    const itemToRemoveIndex = $_SESSION['arr'].findIndex(function (item) {
      return item.row === row;
    });
    if (itemToRemoveIndex !== -1) {
        $_SESSION['arr'].splice(itemToRemoveIndex, 1);
    }
  }