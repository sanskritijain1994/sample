<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculator</title>
</head>
<body>
<?php

if(isset($_POST['operator'])){
    $first = $_POST['first'];
    $second = $_POST['second'];
    $operator = $_POST['operator'];
    if(empty($first) || empty($second) ){
        echo "The Fields Are Empty";
    }
}
    $result = '';
    if(is_numeric($first) && is_numeric($second)){
        switch ($operator) {
            case '+':
                # code...
                $result= $first + $second;
                break;
            case '-':
                #code...
                $result = $first - $second;
                break;
            case '×':
                #code...
                $result = $first * $second;
                break;
            case '÷':
                #code...
                $result = $first / $second;
                break;
            
            default:
                # code...
                echo 'invalid';
                break;
        }
    }
    ?>
        <label for="first">Number 1 : </label>
        <input type="number" id="first" name="first" value="<?php echo $first; ?>"><br><br>
        <label for="second">Number 2 : </label>
        <input type="number" id="second" name="second" value="<?php echo $second; ?>"><br><br>
        <label for="result">Result: </label>
        <input readonly="readonly" name="result" value="<?php echo $result; ?>">
</body>
</html>