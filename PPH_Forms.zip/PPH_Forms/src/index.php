<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Forms</title>
</head>
<body>

    <h2>
        <u>
            Calculate Electricity Bill
        </u>
    </h2>
    <form action="bill.php" method="post" id="bill">
        <input type="number" name="unit" id="unit" placeholder="Enter the no. of units">
        <br><br>
        <input type="submit" name="usubmit" id="usubmit" value="Submit">

    </form>
    <br>
    <hr>
    <br>
    <h2>
        <u>
            Calculator in PHP
        </u>
    </h2>
    <form action="calc.php" method="post" id="calc">
        <label for="first">Number 1 : </label>
        <input type="number" id="first" name="first"><br><br>
        <label for="second">Number 2 : </label>
        <input type="number" id="second" name="second"><br><br>
        <input type="submit" name="operator" value="&#43"  />
        <input type="submit" name="operator" value="&#8722" />
        <input type="submit" name="operator" value="&#215" />
        <input type="submit" name="operator" value="&#247" />
    </form>
    <br>
    <hr>
    <br>
    <h2>
        <u>
            Area and Perimeter of Rectangle
        </u>
    </h2>
    <form action="area.php" method="post" id="area">
    <label for="length">Length of Reactangle : </label>
        <input type="number" id="length" name="length" placeholder="Length in mtr."><br><br>
        <label for="width">Width of Reactangle : </label>
        <input type="number" id="width" name="width" placeholder="Width in mtr."><br><br>  
        <input type="submit" name="calculation" value="Calculate Area & Perimeter"  />
    </form>
    <br>
    <hr>
    <br>
    <h2>
        <u>
            Hour Conversion
        </u>
    </h2>
    <form action="hour.php" method="post" id="hour">
        <input type="text" id="hour" name="hour" placeholder="Enter hour"><br><br>
        <input type="radio" id="min" name="min" value="Minutes" />
        <label for="min">Hour to Minutes</label><br><br>
        <input type="radio" id="sec" name="sec" value="Seconds" />
        <label for="sec">Hour to Seconds</label><br><br>
        
        <input type="submit" name="conversion" value="Convert">
    </form>
    <br>
    <hr>
    <br>
    <h2>
        <u>
            Image Upload
        </u>
    </h2>
    <form action="image.php" method="post" enctype="multipart/form-data">
        <h3>Select image to upload </h3><br><br>
     <input type="file" name="fileToUpload" id="fileToUpload"><br><br>
     <input type="submit" value="Upload Image" name="submit">
    </form>
</body>
</html>