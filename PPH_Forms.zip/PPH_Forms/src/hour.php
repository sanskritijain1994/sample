<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hour Conversion</title>
</head>
<body>
    <?php
    if(isset($_POST['conversion'])){
        $hour = $_POST['hour'];
        //print_r($hour);
        $min = $_POST['min'];
        //print_r($min);
        $sec = $_POST['sec'];
        //print_r($sec);
        if($min){
            $mint = $hour * 60;
            // return $result;
            echo 'The convesion of hour in minutes is : '.$mint.' ' . 'min';
        }
        elseif($sec ){
            $result1 = $hour *3600;
            // return $hour;
            echo 'The convesion of hour in second is : '.$result1.' ' . 'sec';
        }
        else{
            echo 'Please select one radio button';
        }
    }
    ?>
</body>
</html>