<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Area & Perimeter</title>
</head>
<body>
    <?php
    $result = $result1 = $result2 = $result3 = '';
if(isset($_POST['calculation'])){
    $length = $_POST['length'];
    $width = $_POST['width'];
    if(empty($length) || empty($width) ){
        echo "The Fields Are Empty";
    }
    else{
        $result = $length * $width;
        $result1 = 2*($length+$width);
        $result2 = 'Total area of rectangle is =  ' . $result .' '.'sq. mtr.';
        $result3 = 'Total perimeter of rectangle is = '. $result1 .' '.'mtr.';
    }
    echo '<br>'.$result2 .  '<br><br>' . $result3 ;
}
?>
</body>
</html>