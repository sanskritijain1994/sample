<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Bill</title>
</head>
<body>
    <?php

    $result1 = $result = '';

    if(isset($_POST['usubmit'])){
        $unit = $_POST['unit'];
        if(!empty($unit)){
            $result = gen_bill($unit);
            $result1 = 'Total amount of ' . $unit . ' = ' . $result;
        }
    }

    function gen_bill($unit){
        $unit_first = 3.50;
        $unit_second = 4.00;
        $unit_third = 5.20;
        $unit_fourth = 6.50;

        if($unit <= 50){
            $bill = $unit * $unit_first;
        }
        elseif ($unit > 50 && $unit <= 150) {
            # code...
            $bill = $unit * $unit_second;
        }
        elseif ($unit >150 && $unit <= 250) {
            # code...
            $bill = $unit * $unit_third;
        }
        else{
            $bill = $unit * $unit_fourth;
        }
        return number_format((float)$bill, 2, '.', '');
    }
    echo '<br> The Output is : <br><br>'.$result1;

    ?>
</body>
</html>